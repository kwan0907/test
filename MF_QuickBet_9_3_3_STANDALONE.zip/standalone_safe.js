(function(){
if(window.__MF_SAFE_LOCAL__) return;
window.__MF_SAFE_LOCAL__=true;
function q(s){return document.querySelector(s)}
function qa(s){return Array.from(document.querySelectorAll(s))}
function text(e){return e?(e.textContent||'').replace(/\s+/g,' ').trim():''}
function vis(e){return !!e&&e.getClientRects().length>0&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden'}
function num(v){var m=String(v||'').replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):0}
function C(n,r){if(r<0||n<r)return 0;if(r===0||n===r)return 1;r=Math.min(r,n-r);var x=1;for(var i=1;i<=r;i++)x=x*(n-r+i)/i;return Math.round(x)}
function P(n,r){if(r<0||n<r)return 0;var x=1;for(var i=0;i<r;i++)x*=n-i;return x}
function subtype(){
 var a=qa('.mf007_qtb.mf007_btnBOn,.mf007_qtb.mf007_btnOn,.mf007_tb.mf007_btnBOn,.mf007_tb.mf007_btnOn').filter(vis)[0];
 if(a&&a.getAttribute('rel'))return a.getAttribute('rel').toLowerCase();
 var s=qa('.mf007_betLink.mf007_btnLinkOn').filter(vis)[0],id=s?s.id:'';
 return ({mf007_BL_wp:'w',mf007_BL_wpq:'q',mf007_BL_fct:'fct',mf007_BL_tri:'tri',mf007_BL_ff:'ff',mf007_BL_tce:'tce',mf007_BL_qtt:'qtt',mf007_BL_dbl:'dbl'})[id]||'q';
}
function selection(){
 var hs=qa('.mf007_hno').filter(vis).filter(function(e){return /^\d+$/.test(text(e))});
 var bank=hs.filter(function(e){return e.classList.contains('mf007_btnBanker')}).length;
 var legs=hs.filter(function(e){return e.classList.contains('mf007_btnOn')}).length;
 var all=q('#mf007_hno_F');
 if(all&&all.classList.contains('mf007_btnOn'))legs=Math.max(0,hs.length-bank);
 return {bank:bank,legs:legs,total:bank+legs};
}
function count(){
 var t=subtype(),s=selection(),n=s.total,b=s.bank,l=s.legs;
 if(t==='w'||t==='p')return n;
 if(t==='wp')return n*2;
 if(t==='q'||t==='qp')return b>0?C(b,2)+b*l:C(n,2);
 if(t==='qqp')return 2*(b>0?C(b,2)+b*l:C(n,2));
 if(t==='fct'||t==='fctb')return b>0?b*l:P(n,2);
 if(t==='fctbm')return b>0?2*b*l:P(n,2);
 if(t==='tri')return C(n,3);
 if(t==='ff')return C(n,4);
 if(t==='tce')return P(n,3);
 if(t==='qtt')return P(n,4);
 return 0;
}
function stake(){
 var a=qa('.mf007_val.mf007_btnOn').filter(vis)[0];
 var v=num(a?a.getAttribute('rel')||text(a):0);
 return v>0?v:10;
}
function update(){
 var c=count(),u=stake(),total=c*u;
 var a=q('#mf007_bt_input1'),b=q('#mf007_bt_input2');
 if(a)a.textContent=String(c);
 if(b)b.textContent=String(total);
 return {count:c,stake:u,total:total,type:subtype()};
}
function hideLogin(){
 var a=q('#mf007_login');if(a)a.style.display='none';
 var b=q('#mf007_loginDiv');if(b)b.style.display='none';
 qa('.mf007_blockErr,.mf007_betErr').forEach(function(e){
   if(/聰明計算不能使用|用戶尚未登入|尚未登入/.test(text(e)))e.style.display='none';
 });
}
function resultPanel(){
 var r=update(),host=q('#mf007_calbetResultDiv')||q('#mf007_dataArea')||q('#mf007_area');if(!host)return;
 var box=q('#mf007_local_result');
 if(!box){box=document.createElement('div');box.id='mf007_local_result';box.style.cssText='margin:10px 0;padding:10px;border:1px solid #b40000;background:#fff;color:#222;font-size:13px;line-height:1.55;border-radius:4px';host.prepend(box)}
 box.style.display='';
 box.innerHTML='<b>本機計算</b><br>彩池：'+r.type+'<br>注數：<b>'+r.count+'</b><br>每注：<b>$'+r.stake+'</b><br>金額：<b>$'+r.total+'</b><br><span style="color:#666">不需要第三方登入；按目前選馬及膽拖在瀏覽器本機計算。</span>';
}
function ensureButton(){
 if(q('#mf007_local_calc_btn'))return;
 var anchor=q('#mf007_submit')||qa('button,a').find(function(e){return e.closest('#mf007_area')&&/加入注項/.test(text(e))});
 if(!anchor||!anchor.parentElement)return;
 var b=document.createElement('button');
 b.id='mf007_local_calc_btn';b.type='button';b.textContent='本機計算';
 b.style.cssText='margin-right:8px;padding:7px 12px;border:1px solid #b40000;background:#fff;color:#b40000;border-radius:3px;cursor:pointer';
 anchor.parentElement.insertBefore(b,anchor);
}
document.addEventListener('click',function(e){
 var local=e.target.closest?e.target.closest('#mf007_local_calc_btn,#mf007_SbLic,#mf007_ScSbLic,#mf007_calbet,#mf007_SCcalbet'):null;
 if(local){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();resultPanel();return}
 if(e.target.closest&&e.target.closest('#mf007_area'))setTimeout(update,20);
},true);
function boot(){hideLogin();ensureButton();update()}
setTimeout(boot,500);
setInterval(boot,2500);
console.info('[MF Standalone Safe] local calculator active');
})();