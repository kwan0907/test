(() => {
  'use strict';
  const apply = () => {
    const loading = document.getElementById('loading');
    const login = document.getElementById('loginDiv');
    const setting = document.getElementById('settingDiv');
    if (loading) loading.style.display = 'none';
    if (login) login.style.display = 'none';
    if (setting) setting.style.display = 'block';
    document.querySelectorAll('.mf007_memberSection').forEach(el => el.style.display = 'none');
    const purchase = document.getElementById('purchaseBtn');
    if (purchase) purchase.style.display = 'none';
    document.querySelectorAll('.logout-btn').forEach(el => {
      const td = el.closest('td');
      if (td) td.style.display = 'none';
      else el.style.display = 'none';
    });
    ['dd_custid','dd_email','dd_expire','qb_expire','scdd_expire','scqb_expire'].forEach(id => {
      const el = document.getElementById(id);
      const tr = el && el.closest('tr');
      if (tr) tr.style.display = 'none';
    });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply, { once: true });
  else apply();
  const observer = new MutationObserver(apply);
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['style','class'] });
  setInterval(apply, 750);
})();
