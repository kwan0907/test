(()=>{
if(window.__MF_LOCAL_SMART_V5__)return;window.__MF_LOCAL_SMART_V5__=true;
const q=s=>document.querySelector(s),qa=s=>Array.from(document.querySelectorAll(s));
const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden';
const tx=e=>(e?.textContent||'').replace(/\s+/g,' ').trim();
const num=v=>{const m=String(v||'').replace(/,/g,'').match(/-?\d+(?:\.\d+)?/);return m?Number(m[0]):0};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const key='mfLocalSettings';
const defaults={presets:{w:[10,20,50,100],q:[10,20,50,100],fct:[10,20,50,100],tce:[10,20,50,100],tri:[10,20,50,100],ff:[10,20,50,100],qtt:[10,20,50,100],dbl:[10,20,50,100],ex:[10,20,50,100]},selected:{w:10,q:10,fct:10,tce:10,tri:10,ff:10,qtt:10,dbl:10,ex:10},smartBudget:1000};
let cfg=JSON.parse(JSON.stringify(defaults));
const merge=(a,b)=>{if(!b||typeof b!=='object')return a;for(const k in b){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))merge(a[k],b[k]);else a[k]=b[k]}return a};
chrome.storage.local.get(key,r=>{cfg=merge(JSON.parse(JSON.stringify(defaults)),r[key]||{});applyStakePresets()});
chrome.storage.onChanged?.addListener((ch,area)=>{if(area==='local'&&ch[key]){cfg=merge(JSON.parse(JSON.stringify(defaults)),ch[key].newValue||{});applyStakePresets()}});

function patchCors(){if(window.jQuery&&jQuery.cors&&!jQuery.cors.__mfLocal){const orig=jQuery.cors;jQuery.cors=function(o){if(o&&typeof o.url==='string'&&o.url.startsWith('mfstandalone://')){setTimeout(()=>{try{o.success&&o.success({data:''})}catch(_){}},0);return{abort(){}}}return orig.apply(this,arguments)};jQuery.cors.__mfLocal=true}}
function cleanLogin(){const a=q('#mf007_loginDiv');if(a)a.style.display='none';const b=q('#mf007_login');if(b)b.style.display='none';qa('.mf007_logout-btn,.mf007_memberSection').forEach(e=>e.style.display='none');qa('.mf007_blockErr,.mf007_betErr').forEach(e=>{if(/尚未登入|不能使用/.test(tx(e)))e.style.display='none'})}
function raceNo(){const path=location.pathname.split('/').filter(Boolean);const last=path[path.length-1];if(/^\d+$/.test(last))return Number(last);const e=q('.mf007_racenoOn');return num(tx(e))||1}
function activeType(){const e=[...qa('.mf007_qtb.mf007_btnBOn'),...qa('.mf007_qtb.mf007_btnOn'),...qa('.mf007_tb.mf007_btnBOn'),...qa('.mf007_tb.mf007_btnOn')].find(visible);if(e?.getAttribute('rel'))return e.getAttribute('rel').toLowerCase();const id=qa('.mf007_betLink.mf007_btnLinkOn').find(visible)?.id||'';return({mf007_BL_wp:'w',mf007_BL_wpq:'q',mf007_BL_fct:'fct',mf007_BL_tri:'tri',mf007_BL_ff:'ff',mf007_BL_tce:'tce',mf007_BL_qtt:'qtt',mf007_BL_dbl:'dbl'})[id]||'q'}
function poolCode(){const t=activeType();if(['w','p','wp'].includes(t))return'w';if(['q','qp','qqp'].includes(t))return'q';if(['fct','fctb','fctbm'].includes(t))return'fct';return t}
function unitStake(){const a=qa('.mf007_val.mf007_btnOn').find(visible);const v=num(a?.getAttribute('rel')||tx(a));return v>0?v:(Number(cfg.selected[poolCode()])||10)}
function applyStakePresets(){const list=(cfg.presets[poolCode()]||[10]).map(Number).filter(v=>v>0),sel=Number(cfg.selected[poolCode()])||list[0]||10;const cur=qa('.mf007_val').filter(visible);if(!cur.length)return;const parent=cur[0].parentElement;if(!parent)return;const vals=cur.map(e=>num(e.getAttribute('rel')||tx(e))).filter(Boolean);if(vals.length===list.length&&vals.every((v,i)=>v===list[i]))return;cur.forEach(e=>e.remove());list.forEach(v=>{const a=document.createElement('a');a.href='';a.className='mf007_num mf007_val '+(v===sel?'mf007_btnOn':'mf007_btnOff');a.rel=String(v);a.textContent='$'+v;parent.appendChild(a);parent.appendChild(document.createTextNode(' '))})}
function horses(selector){return qa(selector).filter(visible).map(e=>({n:num(e.getAttribute('rel')||tx(e)),el:e})).filter(x=>x.n>0)}
function selection(){
 const hs=horses('.mf007_hno'),bank=hs.filter(x=>x.el.classList.contains('mf007_btnBanker')).map(x=>x.n);
 let legs=hs.filter(x=>x.el.classList.contains('mf007_btnOn')).map(x=>x.n);
 if(q('#mf007_hno_F')?.classList.contains('mf007_btnOn'))legs=hs.map(x=>x.n).filter(n=>!bank.includes(n));
 return{bank:[...new Set(bank)],legs:[...new Set(legs)]}
}
function pairCombos(){
 const s=selection(),all=[...new Set([...s.bank,...s.legs])],pairs=[];
 for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++){const a=all[i],b=all[j];if(!s.bank.length||s.bank.includes(a)||s.bank.includes(b))pairs.push([Math.min(a,b),Math.max(a,b)])}
 return pairs;
}
function singleHorses(){const s=selection();return[...new Set([...s.bank,...s.legs])].sort((a,b)=>a-b)}
function marketName(t){return t==='q'?'QIN':t==='qp'?'QPL':t==='w'?'WIN':t==='p'?'PLA':''}
function findOddsEl(market,a,b){
 const r=raceNo(),direct=[];
 if(b!=null){direct.push('#odds_'+market+'_'+r+'_'+a+'_'+b,'#odds_'+market+'_'+r+'_'+b+'_'+a,'#odds_'+market+'_'+r+'_'+a+'-'+b,'#odds_'+market+'_'+r+'_'+b+'-'+a)}
 else direct.push('#odds_'+market+'_'+r+'_'+a);
 for(const s of direct){const e=q(s);if(e&&tx(e)&&tx(e)!=='退出'&&num(tx(e))>0)return e}
 const prefix='odds_'+market+'_'+r+'_';
 for(const e of qa('[id^="'+prefix+'"]')){const suf=e.id.slice(prefix.length),ns=suf.match(/\d+/g)?.map(Number)||[];if(b==null){if(ns.includes(a)&&ns.length<=2&&num(tx(e))>0)return e}else if(ns.includes(a)&&ns.includes(b)&&num(tx(e))>0)return e}
 return null;
}
function buildEntries(){
 const t=activeType(),out=[];
 if(['q','qp','qqp'].includes(t)){for(const [a,b] of pairCombos()){for(const mt of(t==='qqp'?['QIN','QPL']:[marketName(t)])){const el=findOddsEl(mt,a,b),odds=num(tx(el));out.push({market:mt,label:a+'-'+b,a,b,odds,el})}}}
 else if(['w','p','wp'].includes(t)){for(const h of singleHorses()){for(const mt of(t==='wp'?['WIN','PLA']:[marketName(t)])){const el=findOddsEl(mt,h),odds=num(tx(el));out.push({market:mt,label:String(h),a:h,odds,el})}}}
 return out;
}
function dutch(entries,budget,step=10){
 const valid=entries.filter(x=>x.odds>0&&x.el);const B=Math.floor(Math.max(0,budget)/step)*step;if(!valid.length||B<step)return[];
 const sum=valid.reduce((s,x)=>s+1/x.odds,0);let rows=valid.map(x=>({...x,raw:B*(1/x.odds)/sum,stake:0}));
 if(B>=rows.length*step){rows.forEach(x=>x.stake=Math.max(step,Math.floor(x.raw/step)*step))}else rows.forEach(x=>x.stake=0);
 let used=rows.reduce((s,x)=>s+x.stake,0);
 while(used>B){let c=rows.filter(x=>x.stake>step).sort((a,b)=>(a.raw-a.stake)-(b.raw-b.stake))[0];if(!c)break;c.stake-=step;used-=step}
 while(used+step<=B){let c=rows.sort((a,b)=>(b.raw-b.stake)-(a.raw-a.stake))[0];c.stake+=step;used+=step}
 rows.forEach(x=>x.expected=Math.round(x.stake*x.odds*10)/10);return rows
}
function baseRows(){return buildEntries().map(x=>({...x,stake:unitStake(),expected:Math.round(unitStake()*x.odds*10)/10}))}
function nativeSet(input,value){const p=Object.getPrototypeOf(input),d=Object.getOwnPropertyDescriptor(p,'value');if(d?.set)d.set.call(input,String(value));else input.value=String(value);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));input.blur()}
async function addRows(rows){
 let added=0,failed=0;
 for(const row of rows.filter(x=>x.stake>0&&x.el)){
   const before=qa('.bet-line').length;row.el.click();
   let input=null;
   for(let i=0;i<20;i++){await sleep(80);const ins=qa('.bet-line input[type="text"]');if(ins.length>before){input=ins[before]||ins[ins.length-1];break}}
   if(input){nativeSet(input,row.stake);added++}else failed++;
 }
 return{added,failed}
}
function findPageSend(){
 const selectors=['.betslip-footer .send','.betslip .send','button.send','a.send','.send'];
 for(const s of selectors){for(const e of qa(s)){if(visible(e)&&!e.closest('#mf007_area')&&!e.closest('#mf007_local_smart_panel'))return e}}
 return qa('button,a,[role="button"]').find(e=>visible(e)&&!e.closest('#mf007_area')&&!e.closest('#mf007_local_smart_panel')&&/發送注項|傳送注項|送出投注|Send/i.test(tx(e)))||null
}
function findConfirm(){return q('.preview-dfjs > div > .confirm')||q('.betslip-confirmation-done > .confirm')||qa('button,a,[role="button"]').find(e=>visible(e)&&!e.closest('#mf007_area')&&/^(確定|確認|Confirm)$/i.test(tx(e)))||null}
async function quickSend(rows){
 const r=await addRows(rows);if(!r.added)return r;
 await sleep(250);const send=findPageSend();if(!send)return{...r,stage:'no-send-button'};send.click();
 for(let round=0;round<3;round++){let c=null;for(let i=0;i<25;i++){await sleep(120);c=findConfirm();if(c&&visible(c))break}if(c&&visible(c))c.click();else break}
 return{...r,stage:'sent'}
}
function panelHost(){const h=q('#mf007_dataArea')||q('#mf007_betArea')||q('#mf007_area');if(h){h.style.display='';return h}return null}
function renderSmart(mode='local'){
 const entries=buildEntries(),budget=Math.floor((Number(q('#mf007_local_budget')?.value)||Number(cfg.smartBudget)||1000)/10)*10,rows=dutch(entries,budget,10),host=panelHost();if(!host)return;
 let box=q('#mf007_local_smart_panel');if(!box){box=document.createElement('div');box.id='mf007_local_smart_panel';box.style.cssText='margin:8px 0 12px;padding:10px;border:1px solid #b00000;background:#fff;color:#222;font-size:12px;line-height:1.45;border-radius:4px;max-height:500px;overflow:auto';host.prepend(box)}
 const missing=entries.filter(x=>!x.odds).length,total=rows.reduce((s,x)=>s+x.stake,0),returns=rows.filter(x=>x.stake>0).map(x=>x.expected),minR=returns.length?Math.min(...returns):0,maxR=returns.length?Math.max(...returns):0;
 box.innerHTML='<div style="font-size:16px;font-weight:700;margin-bottom:8px">本機聰明投注（等回報分配）</div>'+
 '<div style="display:flex;gap:6px;align-items:center;margin-bottom:8px"><span>總預算 $</span><input id="mf007_local_budget" type="number" min="10" step="10" value="'+budget+'" style="width:90px;padding:5px"><button id="mf007_local_recalc">重新計算</button></div>'+
 (missing?'<div style="color:#b00000;margin-bottom:6px">有 '+missing+' 個組合暫時讀不到即時賠率，未納入分配。</div>':'')+
 '<table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left">彩池</th><th>組合</th><th>賠率</th><th>注碼</th><th>預計毛回報</th></tr></thead><tbody>'+
 rows.map(x=>'<tr><td>'+x.market+'</td><td style="text-align:center">'+x.label+'</td><td style="text-align:center">'+x.odds+'</td><td style="text-align:center">$'+x.stake+'</td><td style="text-align:center">$'+x.expected.toFixed(1)+'</td></tr>').join('')+
 '</tbody></table><div style="margin-top:8px">合計：<b>$'+total+'</b>　回報範圍：約 <b>$'+minR.toFixed(1)+'–$'+maxR.toFixed(1)+'</b></div>'+
 '<div style="display:flex;gap:7px;margin-top:10px"><button id="mf007_local_add" style="padding:7px 12px">加入投注</button><button id="mf007_local_quick" style="padding:7px 12px;background:#ff9b9b">快速投注</button></div>'+
 '<div id="mf007_local_status" style="margin-top:7px;color:#666">加入投注＝只放入馬會 Bet Slip；快速投注＝加入後自動執行馬會頁面的發送/確認流程。</div>'+
 '<div style="font-size:10px;color:#777;margin-top:8px">這是本機 dutching 替代算法，不是原第三方專有聰明算法；賠率變動後請重新計算。</div>';
 q('#mf007_local_recalc').onclick=e=>{e.preventDefault();cfg.smartBudget=Math.floor((Number(q('#mf007_local_budget').value)||1000)/10)*10;chrome.storage.local.set({[key]:cfg});renderSmart(mode)};
 q('#mf007_local_add').onclick=async e=>{e.preventDefault();const st=q('#mf007_local_status');st.textContent='加入中…';const r=await addRows(rows);st.textContent='完成：加入 '+r.added+' 項'+(r.failed?'，失敗 '+r.failed+' 項':'')};
 q('#mf007_local_quick').onclick=async e=>{e.preventDefault();const st=q('#mf007_local_status');st.textContent='快速投注處理中…';const r=await quickSend(rows);st.textContent=r.stage==='sent'?'已執行發送流程；請留意馬會頁面結果。':('已加入 '+r.added+' 項，但未找到可發送按鈕。')};
}
async function normalAdd(quick=false){
 const rows=baseRows();const st=q('#mf007_local_status');if(quick)return quickSend(rows);return addRows(rows)
}
document.addEventListener('click',e=>{
 const lic=e.target.closest&&e.target.closest('#mf007_SbLic,#mf007_ScSbLic');if(lic){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();renderSmart(lic.id==='mf007_ScSbLic'?'overseas':'local');return}
 const calc=e.target.closest&&e.target.closest('#mf007_calbet,#mf007_SCcalbet');if(calc){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();renderSmart(calc.id==='mf007_SCcalbet'?'overseas':'local');return}
 const add=e.target.closest&&e.target.closest('#mf007_submit');if(add){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();normalAdd(false);return}
 const quick=e.target.closest&&e.target.closest('.mf007_quickBuy');if(quick){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();normalAdd(true);return}
 setTimeout(()=>{applyStakePresets()},0)
},true);
const boot=()=>{patchCors();cleanLogin();applyStakePresets()};boot();setInterval(boot,900);
console.info('[MF Standalone] local smart dutching + add/quick betting active');
})();