(()=>{
if(window.__MF_STANDALONE_V4__)return;window.__MF_STANDALONE_V4__=true;
const q=s=>document.querySelector(s),qa=s=>Array.from(document.querySelectorAll(s));
const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden';
const text=e=>(e?.textContent||'').replace(/\s+/g,' ').trim();
const money=v=>{const m=String(v||'').replace(/,/g,'').match(/\$?\s*(\d+(?:\.\d+)?)/);return m?parseFloat(m[1]):0};
const C=(n,r)=>{if(r<0||n<r)return 0;if(r===0||n===r)return 1;r=Math.min(r,n-r);let x=1;for(let i=1;i<=r;i++)x=x*(n-r+i)/i;return Math.round(x)};
const key='mfLocalSettings';
const defaultCfg={presets:{w:[10,20,50,100],q:[10,20,50,100],fct:[10,20,50,100],tce:[10,20,50,100],tri:[10,20,50,100],ff:[10,20,50,100],qtt:[10,20,50,100],dbl:[10,20,50,100],ex:[10,20,50,100]},selected:{w:10,q:10,fct:10,tce:10,tri:10,ff:10,qtt:10,dbl:10,ex:10}};
let cfg=JSON.parse(JSON.stringify(defaultCfg));
function merge(a,b){if(!b||typeof b!=='object')return a;for(const k in b){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))merge(a[k],b[k]);else a[k]=b[k]}return a}
chrome.storage.local.get(key,r=>{cfg=merge(JSON.parse(JSON.stringify(defaultCfg)),r[key]||{});applyStakePresets()});
chrome.storage.onChanged?.addListener((changes,area)=>{if(area==='local'&&changes[key]){cfg=merge(JSON.parse(JSON.stringify(defaultCfg)),changes[key].newValue||{});applyStakePresets()}});

function poolCode(){
 const active=[...qa('.mf007_qtb.mf007_btnBOn'),...qa('.mf007_qtb.mf007_btnOn'),...qa('.mf007_tb.mf007_btnBOn'),...qa('.mf007_tb.mf007_btnOn')].filter(visible)[0];
 let rel=(active?.getAttribute('rel')||'').toLowerCase();
 if(['w','p','wp'].includes(rel))return'w';
 if(['q','qp','qqp'].includes(rel))return'q';
 if(['fct','fctb','fctbm'].includes(rel))return'fct';
 if(['tce','tri','ff','qtt','dbl'].includes(rel))return rel;
 const side=qa('.mf007_betLink.mf007_btnLinkOn').find(visible)?.id||'';
 return({mf007_BL_wp:'w',mf007_BL_wpq:'q',mf007_BL_fct:'fct',mf007_BL_tce:'tce',mf007_BL_tri:'tri',mf007_BL_ff:'ff',mf007_BL_qtt:'qtt',mf007_BL_dbl:'dbl'})[side]||'w';
}
function activeType(){
 const active=[...qa('.mf007_qtb.mf007_btnBOn'),...qa('.mf007_qtb.mf007_btnOn'),...qa('.mf007_tb.mf007_btnBOn'),...qa('.mf007_tb.mf007_btnOn')].filter(visible)[0];
 if(active?.getAttribute('rel'))return active.getAttribute('rel').toLowerCase();
 return poolCode();
}
function selectedCount(selector,fieldSelector){
 const field=q(fieldSelector);
 if(field&&(field.classList.contains('mf007_btnOn')||field.classList.contains('mf007_btnBOn')))return qa(selector).filter(visible).filter(e=>!e.classList.contains('disabled')).length;
 return qa(selector).filter(visible).filter(e=>e.classList.contains('mf007_btnOn')).length;
}
function bankerCount(){return qa('.mf007_hno').filter(visible).filter(e=>e.classList.contains('mf007_btnBanker')).length}
function unitStake(){
 const active=qa('.mf007_val.mf007_btnOn').filter(visible)[0];
 if(active){const r=money(active.getAttribute('rel'));if(r>0)return r;const t=money(text(active));if(t>0)return t}
 return Number(cfg.selected[poolCode()])||10;
}
function calc(type,n,b){
 if(type==='w'||type==='p')return n;if(type==='wp')return n*2;
 if(type==='q'||type==='qp')return n>0?(b>0?n:C(n,2)):0;
 if(type==='qqp')return n>0?(b>0?n*2:C(n,2)*2):0;
 if(type==='fct'||type==='fctb')return n>0?(b>0?n:C(n,2)*2):0;
 if(type==='fctbm')return n>0?(b>0?n*2:C(n,2)*2):0;
 if(type==='tri')return b===1?C(n,2):b===2?n:C(n,3);
 if(type==='ff')return b===1?C(n,3):b===2?C(n,2):b===3?n:C(n,4);
 if(type==='tce')return (b===1?C(n,2):b===2?n:C(n,3))*6;
 if(type==='qtt')return (b===1?C(n,3):b===2?C(n,2):b===3?n:C(n,4))*24;
 return 0;
}
function calculate(){
 const type=activeType(),stake=unitStake();
 if(type==='dbl'){const a=selectedCount('.mf007_hno','#mf007_hno_F'),b=selectedCount('.mf007_hno2','#mf007_hno2_F');return{type,count:a*b,stake,total:a*b*stake,detail:'第一場 '+a+' × 第二場 '+b}}
 const n=selectedCount('.mf007_hno','#mf007_hno_F'),b=bankerCount(),count=calc(type,n,b);return{type,count,stake,total:count*stake,detail:'選擇 '+n+'｜膽 '+b}
}
function setTxt(id,v){const e=q(id);if(e)e.textContent=String(v)}
function updateTotals(){const r=calculate();setTxt('#mf007_bt_input1',r.count);setTxt('#mf007_bt_input2',Math.round(r.total*100)/100);return r}
function patchCors(){
 if(window.jQuery&&jQuery.cors&&!jQuery.cors.__local){const orig=jQuery.cors;jQuery.cors=function(o){if(o&&typeof o.url==='string'&&o.url.startsWith('mfstandalone://')){setTimeout(()=>{try{o.success&&o.success({data:''})}catch(_){}},0);return{abort(){}}}return orig.apply(this,arguments)};jQuery.cors.__local=true}
}
function cleanLogin(){
 const d=q('#mf007_loginDiv');if(d)d.style.display='none';const l=q('#mf007_login');if(l)l.style.display='none';
 qa('.mf007_logout-btn').forEach(e=>e.style.display='none');
 qa('.mf007_blockErr,.mf007_betErr').forEach(e=>{if(/尚未登入/.test(text(e)))e.style.display='none'})
}
function applyStakePresets(){
 const code=poolCode(),list=(cfg.presets[code]||[10]).map(Number).filter(v=>v>0),sel=Number(cfg.selected[code])||list[0]||10;
 const current=qa('.mf007_val').filter(visible);
 if(!current.length)return;
 const parent=current[0].parentElement;if(!parent)return;
 const vals=current.map(e=>money(e.getAttribute('rel'))||money(text(e))).filter(v=>v>0);
 if(vals.length===list.length&&vals.every((v,i)=>Number(v)===Number(list[i])))return;
 current.forEach(e=>e.remove());
 list.forEach(v=>{const a=document.createElement('a');a.href='';a.className='mf007_num mf007_val '+(Number(v)===Number(sel)?'mf007_btnOn':'mf007_btnOff');a.setAttribute('rel',String(v));a.textContent='$'+v;a.style.marginRight='4px';parent.appendChild(a);parent.appendChild(document.createTextNode(' '))});
}
function smartPanel(source){
 const r=updateTotals(),host=q('#mf007_calbetResultDiv')||q('#mf007_dataArea');if(!host)return;
 host.style.display='';
 let box=q('#mf007_local_smart_panel');if(!box){box=document.createElement('div');box.id='mf007_local_smart_panel';box.style.cssText='margin:8px 0 12px;padding:12px;border:1px solid #b40000;background:#fff;color:#222;font-size:13px;line-height:1.55;border-radius:4px';host.prepend(box)}
 const label=({w:'獨贏',p:'位置',wp:'獨贏+位置',q:'連贏',qp:'位置Q',qqp:'連贏+位置Q',fct:'二重',fctb:'二重',fctbm:'二重',tri:'單T',ff:'四連',tce:'三重',qtt:'四重',dbl:'孖寶'})[r.type]||r.type;
 box.innerHTML='<div style="font-weight:700;font-size:15px;margin-bottom:6px">本機聰明投注</div>'+
 '<div>模式：'+(source==='overseas'?'海外聰明':'聰明')+'</div><div>彩池：'+label+'</div><div>'+r.detail+'</div>'+
 '<div style="margin-top:6px">注數：<b>'+r.count+'</b>　每注：<b>$'+r.stake+'</b></div><div>總金額：<b>$'+(Math.round(r.total*100)/100)+'</b></div>'+
 '<button id="mf007_local_smart_calc" style="margin-top:10px;padding:7px 14px;border:1px solid #999;background:#eee;border-radius:3px;cursor:pointer">重新計算</button>'+
 '<div style="font-size:11px;color:#666;margin-top:8px">這是本機替代聰明計算，使用目前選馬、膽拖及注碼計算；不使用原第三方專有派彩／配對 API。</div>';
 q('#mf007_local_smart_calc')?.addEventListener('click',e=>{e.preventDefault();smartPanel(source)},{once:true});
}
function activateSmart(which){
 const local=q('#mf007_SbLic'),over=q('#mf007_ScSbLic');
 [local,over].forEach(e=>{if(e){e.classList.remove('mf007_LicOn');e.classList.add('mf007_LicOff')}});
 const target=which==='overseas'?over:local;if(target){target.classList.remove('mf007_LicOff');target.classList.add('mf007_LicOn')}
 smartPanel(which);
}
document.addEventListener('click',e=>{
 const btn=e.target.closest&&e.target.closest('#mf007_SbLic,#mf007_ScSbLic');
 if(btn){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();activateSmart(btn.id==='mf007_ScSbLic'?'overseas':'local');return}
 const smart=e.target.closest&&e.target.closest('#mf007_calbet,#mf007_SCcalbet');
 if(smart){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();smartPanel(smart.id==='mf007_SCcalbet'?'overseas':'local');return}
 setTimeout(()=>{applyStakePresets();updateTotals()},0);
},true);
document.addEventListener('change',()=>setTimeout(()=>{applyStakePresets();updateTotals()},0),true);
const boot=()=>{patchCors();cleanLogin();applyStakePresets();updateTotals()};
boot();setInterval(boot,700);
console.info('[MF Standalone] v4 local settings + smart calculation active');
})();