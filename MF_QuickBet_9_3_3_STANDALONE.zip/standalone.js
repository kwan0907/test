(()=>{
if(window.__MF_STANDALONE_LOCAL_V3__)return;
window.__MF_STANDALONE_LOCAL_V3__=true;

const q=s=>document.querySelector(s);
const qa=s=>Array.from(document.querySelectorAll(s));
const visible=e=>!!e&&e.getClientRects().length>0&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden';
const text=e=>(e?.textContent||'').replace(/\s+/g,' ').trim();
const toMoney=v=>{const m=String(v||'').replace(/,/g,'').match(/\$?\s*(\d+(?:\.\d+)?)/);return m?parseFloat(m[1]):0};
const C=(n,r)=>{if(r<0||n<r)return 0;if(r===0||n===r)return 1;r=Math.min(r,n-r);let x=1;for(let i=1;i<=r;i++)x=x*(n-r+i)/i;return Math.round(x)};

function visibleHorseCount(selector){
  return qa(selector).filter(visible).filter(e=>!e.classList.contains('disabled')).length;
}
function selectedCount(selector,fieldSelector){
  const field=q(fieldSelector);
  if(field&&(field.classList.contains('mf007_btnOn')||field.classList.contains('mf007_btnBOn'))){
    return visibleHorseCount(selector);
  }
  return qa(selector).filter(visible).filter(e=>e.classList.contains('mf007_btnOn')).length;
}
function bankerCount(){
  return qa('.mf007_hno').filter(visible).filter(e=>e.classList.contains('mf007_btnBanker')).length;
}
function activeType(){
  const candidates=[
    ...qa('.mf007_qtb.mf007_btnBOn'),
    ...qa('.mf007_qtb.mf007_btnOn'),
    ...qa('.mf007_tb.mf007_btnBOn'),
    ...qa('.mf007_tb.mf007_btnOn')
  ].filter(visible);
  for(const e of candidates){const rel=(e.getAttribute('rel')||'').toLowerCase();if(rel)return rel}
  const side=qa('.mf007_betLink.mf007_btnLinkOn').find(visible);
  const map={mf007_BL_wp:'w',mf007_BL_wpq:'q',mf007_BL_fct:'fct',mf007_BL_tri:'tri',mf007_BL_ff:'ff',mf007_BL_tce:'tce',mf007_BL_qtt:'qtt',mf007_BL_dbl:'dbl'};
  return map[side?.id||'']||'w';
}
function activeLabel(type){
  const labels={w:'獨贏',p:'位置',wp:'獨贏 + 位置',q:'連贏',qp:'位置Q',qqp:'連贏 + 位置Q',fct:'二重',fctb:'二重',fctbm:'二重',tri:'單T',ff:'四連',tce:'三重',qtt:'四重',dbl:'孖寶'};
  return labels[type]||type;
}
function unitStake(){
  for(const e of qa('.mf007_val.mf007_btnOn').filter(visible)){
    const rel=toMoney(e.getAttribute('rel'));if(rel>0)return rel;
    const v=toMoney(text(e));if(v>0)return v;
  }
  return 10;
}
function calcSingle(type,n,b){
  switch(type){
    case'w':case'p':return n;
    case'wp':return n*2;
    case'q':case'qp':return n>0?(b>0?n:C(n,2)):0;
    case'qqp':return n>0?(b>0?n*2:C(n,2)*2):0;
    case'fct':case'fctb':return n>0?(b>0?n:C(n,2)*2):0;
    case'fctbm':return n>0?(b>0?n*2:C(n,2)*2):0;
    case'tri':
      if(b===1)return n>1?C(n,2):0;
      if(b===2)return n>0?n:0;
      return n>2?C(n,3):0;
    case'ff':
      if(b===1)return n>2?C(n,3):0;
      if(b===2)return n>1?C(n,2):0;
      if(b===3)return n>0?n:0;
      return n>3?C(n,4):0;
    case'tce':
      if(b===1)return n>1?C(n,2)*6:0;
      if(b===2)return n>0?n*6:0;
      return n>2?C(n,3)*6:0;
    case'qtt':
      if(b===1)return n>2?C(n,3)*24:0;
      if(b===2)return n>1?C(n,2)*24:0;
      if(b===3)return n>0?n*24:0;
      return n>3?C(n,4)*24:0;
    default:return 0;
  }
}
function calculate(){
  const type=activeType(),stake=unitStake();
  let count=0,detail={};
  if(type==='dbl'){
    const first=selectedCount('.mf007_hno','#mf007_hno_F');
    const second=selectedCount('.mf007_hno2','#mf007_hno2_F');
    count=first*second;detail={first,second};
  }else{
    const n=selectedCount('.mf007_hno','#mf007_hno_F'),b=bankerCount();
    count=calcSingle(type,n,b);detail={selected:n,bankers:b};
  }
  return{type,label:activeLabel(type),count,stake,total:Math.round((count*stake+Number.EPSILON)*100)/100,detail};
}
function setText(id,value){const e=q(id);if(e&&text(e)!==String(value))e.textContent=String(value)}
function updateTotals(){const r=calculate();setText('#mf007_bt_input1',r.count);setText('#mf007_bt_input2',r.total);return r}
function hideLoginGates(){
  const a=q('#mf007_loginDiv');if(a)a.style.display='none';
  const b=q('#mf007_login');if(b)b.style.display='none';
  qa('.mf007_memberSection,.mf007_member-btn,.mf007_logout-btn').forEach(e=>e.style.display='none');
  qa('.mf007_blockErr,.mf007_betErr').forEach(e=>{if(/聰明計算不能使用|用戶尚未登入|尚未登入/.test(text(e)))e.style.display='none'});
}
function patchCors(){
  if(window.jQuery&&jQuery.cors&&!jQuery.cors.__mfStandalone){
    const orig=jQuery.cors;
    jQuery.cors=function(opts){
      if(opts&&typeof opts.url==='string'&&opts.url.startsWith('mfstandalone://')){
        setTimeout(()=>{try{opts.success&&opts.success({data:''})}catch(_){}},0);
        return{abort(){}};
      }
      return orig.apply(this,arguments);
    };
    jQuery.cors.__mfStandalone=true;
  }
}
function showLocalResult(){
  const r=updateTotals();
  const host=q('#mf007_calbetResultDiv')||q('#mf007_dataArea')||q('#mf007_area');if(!host)return;
  host.style.display='';
  let box=q('#mf007_local_calc_result');
  if(!box){box=document.createElement('div');box.id='mf007_local_calc_result';box.style.cssText='margin:10px 0;padding:10px;border:1px solid #bb0000;background:#fff;color:#222;font-size:13px;line-height:1.65;border-radius:4px';host.prepend(box)}
  const d=r.type==='dbl'?('第一場選擇：'+r.detail.first+'　第二場選擇：'+r.detail.second):('選擇：'+r.detail.selected+'　膽：'+r.detail.bankers);
  box.innerHTML='<b>本機計算</b><br>彩池：'+r.label+'<br>'+d+'<br>注數：<b>'+r.count+'</b><br>每注：$'+r.stake+'<br>金額：<b>$'+r.total+'</b><br><span style="color:#666">按目前選馬組合在瀏覽器本機計算，不使用第三方會員或私人聰明計算 API。</span>';
}
const smart=['#mf007_calbet','#mf007_SCcalbet','.mf007_calbetSubmit_win','.mf007_calbetSubmit_dbl','.mf007_calbetSubmit_fct','.mf007_calbetSubmit_qin','.mf007_calbetRbSubmit_qin','.mf007_calbetHtSubmit_qin','.mf007_calbetSubmit_qpl','.mf007_calbetSubmit_allQF','.mf007_calbetSubmit_fctQF','.mf007_calbetSubmit_qinQF'].join(',');
document.addEventListener('click',e=>{
  const s=e.target.closest&&e.target.closest(smart);
  if(s){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();s.removeAttribute('disabled');showLocalResult();return}
  setTimeout(()=>{hideLoginGates();updateTotals()},0);
},true);
document.addEventListener('change',()=>setTimeout(updateTotals,0),true);
document.addEventListener('input',()=>setTimeout(updateTotals,0),true);
const boot=()=>{patchCors();hideLoginGates();updateTotals()};
boot();setInterval(boot,500);
console.info('[MF Standalone] local bet-count/amount engine active');
})();