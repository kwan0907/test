(() => {
  'use strict';
  const apply = () => {
    const login = document.getElementById('mf007_loginDiv');
    if (login) login.style.display = 'none';
    document.querySelectorAll('.mf007_logout-btn,.mf007_member-btn').forEach(el => el.style.display = 'none');
    document.querySelectorAll('#mf007_settingDiv .mf007_memberSection').forEach(el => el.style.display = 'none');
  };
  apply();
  new MutationObserver(apply).observe(document.documentElement, { childList: true, subtree: true });
})();
