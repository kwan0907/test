document.addEventListener('DOMContentLoaded',()=>{
const $=s=>document.querySelector(s);
const key='mfLocalSettings';
const defaults={presets:{w:[10,20,50,100],q:[10,20,50,100],fct:[10,20,50,100],tce:[10,20,50,100],tri:[10,20,50,100],ff:[10,20,50,100],qtt:[10,20,50,100],dbl:[10,20,50,100],ex:[10,20,50,100]},selected:{w:10,q:10,fct:10,tce:10,tri:10,ff:10,qtt:10,dbl:10,ex:10},smartBudget:1000};
let cfg=JSON.parse(JSON.stringify(defaults));
const merge=(a,b)=>{if(!b||typeof b!=='object')return a;for(const k in b){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))merge(a[k],b[k]);else a[k]=b[k]}return a};
const show=(s,on)=>{const e=$(s);if(e)e.style.display=on?'':'none'};
show('#loading',false);show('#loginDiv',false);show('#settingDiv',true);show('#purchaseBtn',false);show('#logout-btn',false);
const put=(id,v)=>{const e=$(id);if(e)e.textContent=v};put('#dd_custid','Standalone');put('#dd_email','Local');put('#dd_expire','本機');put('#qb_expire','本機');put('#scdd_expire','本機');put('#scqb_expire','本機');const av=$('#appver');if(av)av.textContent=' v9.3.3 local';
chrome.storage.local.get(key,r=>{cfg=merge(JSON.parse(JSON.stringify(defaults)),r[key]||{});
 const area=$('#settingArea')||$('#settingDiv'); if(area&&!$('#mfLocalBudgetRow')){const d=document.createElement('div');d.id='mfLocalBudgetRow';d.style.cssText='margin:12px 0;padding:10px;border-top:1px solid #ccc';d.innerHTML='<div style="font-weight:700;margin-bottom:6px">本機聰明投注預算</div><input id="mfLocalBudget" type="number" min="10" step="10" style="width:100%;box-sizing:border-box;padding:7px" value="'+Number(cfg.smartBudget||1000)+'"><div style="font-size:11px;color:#666;margin-top:5px">聰明投注會按即時賠率以 $10 步進分配。</div>';area.appendChild(d)}
});
$('#save-btn')?.addEventListener('click',e=>{e.preventDefault();const b=Math.max(10,Math.floor((Number($('#mfLocalBudget')?.value)||1000)/10)*10);cfg.smartBudget=b;chrome.storage.local.set({[key]:cfg},()=>{e.target.textContent='已儲存 ✓';setTimeout(()=>e.target.textContent='儲存',800)})});
});