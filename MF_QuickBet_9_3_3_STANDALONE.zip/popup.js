document.addEventListener('DOMContentLoaded',()=>{
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  const defaults={
    presets:{w:[10,20,50,100],q:[10,20,50,100],fct:[10,20,50,100],tce:[10,20,50,100],tri:[10,20,50,100],ff:[10,20,50,100],qtt:[10,20,50,100],dbl:[10,20,50,100],ex:[10,20,50,100]},
    selected:{w:10,q:10,fct:10,tce:10,tri:10,ff:10,qtt:10,dbl:10,ex:10},
    rebate:{wr:0,qr:0},pc:[10,20,50],other:{eng:0,range:1,autoBet:0}
  };
  const key='mfLocalSettings';
  let cfg=JSON.parse(JSON.stringify(defaults));
  const show=(id,on)=>{const e=$(id);if(e)e.style.display=on?'':'none'};
  const moneyList=v=>[...new Set(String(v||'').split(/[,，\s]+/).map(x=>parseFloat(x)).filter(x=>Number.isFinite(x)&&x>0))].slice(0,12);
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function merge(base,val){
    if(!val||typeof val!=='object')return base;
    for(const k of Object.keys(val)){
      if(val[k]&&typeof val[k]==='object'&&!Array.isArray(val[k])&&base[k]&&typeof base[k]==='object'&&!Array.isArray(base[k]))merge(base[k],val[k]);
      else base[k]=val[k];
    } return base;
  }
  const poolAreas={w:'wpBetList',wr:'wprBetList',q:'qpBetList',qr:'qprBetList',fct:'fctBetList',tce:'tceBetList',tri:'triBetList',ff:'ffBetList',qtt:'qttBetList',dbl:'dblBetList',ex:'exBetList',pc:'pcBetList',other:'otherList'};
  const names={w:'獨贏 / 位置',q:'連贏 / 位置Q',fct:'二重彩',tce:'三重彩',tri:'單T',ff:'四連環',qtt:'四重彩',dbl:'孖寶',ex:'其他'};
  function betEditor(k){
    const list=cfg.presets[k]||[10], selected=cfg.selected[k]||list[0]||10;
    return '<div style="padding:4px 0 8px"><div style="font-weight:700;margin-bottom:7px">'+esc(names[k]||k)+' 投注額</div>'+
      '<div style="font-size:12px;margin-bottom:5px">可用注碼（逗號分隔）</div>'+
      '<input data-preset="'+k+'" style="box-sizing:border-box;width:100%;padding:8px;border:1px solid #bbb;border-radius:4px;font-size:14px" value="'+esc(list.join(', '))+'">'+
      '<div style="font-size:12px;margin:10px 0 5px">預設注碼</div>'+
      '<select data-default="'+k+'" style="box-sizing:border-box;width:100%;padding:7px;border:1px solid #bbb;border-radius:4px">'+
      list.map(v=>'<option value="'+v+'" '+(Number(v)===Number(selected)?'selected':'')+'>$'+v+'</option>').join('')+
      '</select><div style="font-size:11px;color:#666;margin-top:8px">儲存後，投注視窗的綠色注碼按鈕會即時更新。</div></div>';
  }
  function render(){
    Object.entries(poolAreas).forEach(([k,id])=>{const el=$('#'+id);if(el)el.style.display='none'});
    for(const k of ['w','q','fct','tce','tri','ff','qtt','dbl','ex']){
      const el=$('#'+poolAreas[k]);if(el)el.innerHTML=betEditor(k);
    }
    const wr=$('#wprBetList');if(wr)wr.innerHTML='<div style="padding:4px 0"><div style="font-weight:700;margin-bottom:7px">獨贏回扣額度</div><input id="local_wr" type="number" min="0" step="1" value="'+(cfg.rebate.wr||0)+'" style="box-sizing:border-box;width:100%;padding:8px;border:1px solid #bbb;border-radius:4px"><div style="font-size:11px;color:#666;margin-top:8px">本機設定；不連接第三方會員伺服器。</div></div>';
    const qr=$('#qprBetList');if(qr)qr.innerHTML='<div style="padding:4px 0"><div style="font-weight:700;margin-bottom:7px">連贏 / 位置Q 回扣額度</div><input id="local_qr" type="number" min="0" step="1" value="'+(cfg.rebate.qr||0)+'" style="box-sizing:border-box;width:100%;padding:8px;border:1px solid #bbb;border-radius:4px"></div>';
    const pc=$('#pcBetList');if(pc)pc.innerHTML='<div style="padding:4px 0"><div style="font-weight:700;margin-bottom:7px">有波加注注碼</div><input id="local_pc" value="'+esc((cfg.pc||[]).join(', '))+'" style="box-sizing:border-box;width:100%;padding:8px;border:1px solid #bbb;border-radius:4px"></div>';
    const other=$('#otherList');if(other){
      other.style.display='none';
      const eng=$('#otherEng'),range=$('#otherRange'),auto=$('#otherAutoBet'),sc=$('#otherSC');
      if(eng)eng.innerHTML='<select id="local_eng"><option value="0">中文</option><option value="1">English</option></select>';
      if(range)range.innerHTML='<select id="local_range"><option value="1">顯示</option><option value="0">隱藏</option></select>';
      if(auto)auto.innerHTML='<select id="local_autobet"><option value="0">關閉</option><option value="1">開啟</option></select>';
      if(sc)sc.textContent='本機';
    }
    switchArea($('#betListType')?.value||'w');
  }
  function switchArea(v){
    Object.values(poolAreas).forEach(id=>{const e=$('#'+id);if(e)e.style.display='none'});
    const id=poolAreas[v]||poolAreas.w;const e=$('#'+id);if(e)e.style.display='';
  }
  function save(){
    for(const k of ['w','q','fct','tce','tri','ff','qtt','dbl','ex']){
      const inp=document.querySelector('[data-preset="'+k+'"]');
      const sel=document.querySelector('[data-default="'+k+'"]');
      const list=moneyList(inp?.value);
      if(list.length){cfg.presets[k]=list;cfg.selected[k]=Number(sel?.value)||list[0]}
    }
    cfg.rebate.wr=Math.max(0,Number($('#local_wr')?.value)||0);
    cfg.rebate.qr=Math.max(0,Number($('#local_qr')?.value)||0);
    cfg.pc=moneyList($('#local_pc')?.value);
    cfg.other.eng=Number($('#local_eng')?.value)||0;
    cfg.other.range=Number($('#local_range')?.value)||0;
    cfg.other.autoBet=Number($('#local_autobet')?.value)||0;
    chrome.storage.local.set({[key]:cfg},()=>{
      const b=$('#save-btn');if(b){const old=b.textContent;b.textContent='已儲存 ✓';setTimeout(()=>b.textContent=old,900)}
      render();
    });
  }

  show('#loading',false);show('#loginDiv',false);show('#settingDiv',true);show('#purchaseBtn',false);show('#logout-btn',false);
  const put=(id,v)=>{const e=$(id);if(e)e.textContent=v};
  put('#dd_custid','Standalone');put('#dd_email','Local');put('#dd_expire','本機');put('#qb_expire','本機');put('#scdd_expire','本機');put('#scqb_expire','本機');
  const av=$('#appver');if(av)av.textContent=' v9.3.3 local';
  chrome.storage.local.get(key,res=>{cfg=merge(JSON.parse(JSON.stringify(defaults)),res[key]||{});render();
    const eng=$('#local_eng'),range=$('#local_range'),auto=$('#local_autobet');
    if(eng)eng.value=String(cfg.other.eng||0);if(range)range.value=String(cfg.other.range??1);if(auto)auto.value=String(cfg.other.autoBet||0);
  });
  $('#betListType')?.addEventListener('change',e=>switchArea(e.target.value));
  $('#save-btn')?.addEventListener('click',e=>{e.preventDefault();save()});
});