/* authentication disabled: unrestricted local mode */
globalThis.PluginAdminAuthRuntime = Object.freeze({
  create() {
    return {
      install() {},
      async report() {
        return { success: true, skipped: true, reason: 'auth-disabled' };
      },
      async revalidate() {
        return { success: true, skipped: true, reason: 'auth-disabled' };
      }
    };
  }
});
