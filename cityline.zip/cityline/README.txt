Cityline 私人購票助手 v0.1.0

用途
- Cityline 專用 Chrome Manifest V3 擴充功能。
- 與 hkticketing.zip 完全分開，兩個可以同時保留／安裝。

已做
- Cityline Events / event / venue.cityline.com 頁面監察
- 活動名稱、場次、票價／區域、數量
- 快速購票／一般購票選擇
- 會員登入資料本機自動填寫（可選擇自動登入）
- 排隊頁偵測：不會自行快速刷新或繞過排隊
- CAPTCHA／人機驗證偵測：停下給使用者處理
- 付款／3D Secure／交易預覽：停下給使用者本人處理
- 成功頁／網上收據偵測
- 本機 Chrome 通知
- 使用者自己的 Feishu / Lark / Telegram / Bark / ntfy 通知
- 本機日誌
- 無啟動碼、無遠端授權、無作者 telemetry、無成功事件回傳

安裝
1. 解壓 cityline.zip。
2. Chrome -> 擴充功能 -> 管理擴充功能。
3. 開啟「開發人員模式」。
4. 選「載入未封裝項目」。
5. 選擇解壓後的 cityline 資料夾。

注意
Cityline 現時首頁是 JavaScript/Vue 網站，而不同活動的購票頁 DOM 可能不同。
v0.1.0 使用文字／表單語意做通用偵測；實際熱門活動測試後，可以再針對該活動頁做更精準 selector。
