(() => {
  "use strict";

  const $ = id => document.getElementById(id);

  const defaults = {
    scriptEnabled: true,
    eventKeyword: "",
    directEventUrl: "",
    performanceKeyword: "",
    priceKeyword: "",
    quantity: 1,
    purchaseMode: "express",
    memberLogin: "",
    memberPassword: "",
    autoSubmitLogin: false,
    notifications: {
      feishuWebhook: "",
      larkWebhook: "",
      telegramBotToken: "",
      telegramChatId: "",
      barkKey: "",
      ntfyTopic: ""
    }
  };

  async function load() {
    const data = await chrome.storage.local.get([
      "citylineConfig",
      "citylineRuntimeStatus",
      "citylineLogs"
    ]);
    const cfg = Object.assign({}, defaults, data.citylineConfig || {}, {
      notifications: Object.assign({}, defaults.notifications, data.citylineConfig?.notifications || {})
    });

    $("scriptEnabled").checked = cfg.scriptEnabled !== false;
    $("eventKeyword").value = cfg.eventKeyword || "";
    $("directEventUrl").value = cfg.directEventUrl || "";
    $("performanceKeyword").value = cfg.performanceKeyword || "";
    $("priceKeyword").value = cfg.priceKeyword || "";
    $("quantity").value = cfg.quantity || 1;
    $("purchaseMode").value = cfg.purchaseMode || "express";
    $("memberLogin").value = cfg.memberLogin || "";
    $("memberPassword").value = cfg.memberPassword || "";
    $("autoSubmitLogin").checked = !!cfg.autoSubmitLogin;

    $("feishuWebhook").value = cfg.notifications.feishuWebhook || "";
    $("larkWebhook").value = cfg.notifications.larkWebhook || "";
    $("telegramBotToken").value = cfg.notifications.telegramBotToken || "";
    $("telegramChatId").value = cfg.notifications.telegramChatId || "";
    $("barkKey").value = cfg.notifications.barkKey || "";
    $("ntfyTopic").value = cfg.notifications.ntfyTopic || "";

    renderStatus(data.citylineRuntimeStatus);
    renderLogs(data.citylineLogs || []);
  }

  function collect() {
    return {
      scriptEnabled: $("scriptEnabled").checked,
      eventKeyword: $("eventKeyword").value.trim(),
      directEventUrl: $("directEventUrl").value.trim(),
      performanceKeyword: $("performanceKeyword").value.trim(),
      priceKeyword: $("priceKeyword").value.trim(),
      quantity: Math.max(1, Number($("quantity").value) || 1),
      purchaseMode: $("purchaseMode").value,
      memberLogin: $("memberLogin").value.trim(),
      memberPassword: $("memberPassword").value,
      autoSubmitLogin: $("autoSubmitLogin").checked,
      notifications: {
        feishuWebhook: $("feishuWebhook").value.trim(),
        larkWebhook: $("larkWebhook").value.trim(),
        telegramBotToken: $("telegramBotToken").value.trim(),
        telegramChatId: $("telegramChatId").value.trim(),
        barkKey: $("barkKey").value.trim(),
        ntfyTopic: $("ntfyTopic").value.trim()
      }
    };
  }

  async function save() {
    await chrome.storage.local.set({ citylineConfig: collect() });
    $("saveBtn").textContent = "已保存 ✓";
    setTimeout(() => $("saveBtn").textContent = "保存設定", 1200);
  }

  function renderStatus(st) {
    const title = $("statusTitle");
    const detail = $("statusDetail");
    if (!st) {
      title.textContent = "等待 Cityline";
      detail.textContent = "尚未偵測頁面";
      return;
    }
    const map = {
      paused: "已暫停",
      queue: "排隊中",
      human: "需要人手驗證",
      payment: "付款步驟",
      confirm: "最後確認",
      success: "成功",
      error: "錯誤",
      watching: "監察中",
      event: "活動",
      performance: "場次",
      price: "票價",
      quantity: "數量",
      mode: "購票模式",
      checkout: "結帳",
      buy: "進行中",
      login: "登入"
    };
    title.textContent = map[st.state] || st.state || "Cityline";
    detail.textContent = st.detail || st.url || "";
  }

  function renderLogs(logs) {
    const root = $("logs");
    root.textContent = "";
    if (!Array.isArray(logs) || !logs.length) {
      root.textContent = "暫時未有日誌";
      return;
    }
    for (const item of logs.slice(0, 40)) {
      const row = document.createElement("div");
      row.className = "log " + (item.level || "");
      const meta = document.createElement("div");
      meta.className = "meta";
      meta.textContent = new Date(item.at || Date.now()).toLocaleTimeString() + " · " + (item.level || "info");
      const msg = document.createElement("div");
      msg.textContent = item.message || "";
      row.append(meta, msg);
      root.appendChild(row);
    }
  }

  $("saveBtn").addEventListener("click", save);

  $("scriptEnabled").addEventListener("change", save);

  $("openBtn").addEventListener("click", async () => {
    const cfg = collect();
    await chrome.tabs.create({
      url: cfg.directEventUrl || "https://www.cityline.com/Events.html"
    });
  });

  $("runBtn").addEventListener("click", async () => {
    await save();
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { action: "CITYLINE_RUN_NOW" });
    } catch (_) {}
  });

  $("testNotifyBtn").addEventListener("click", async () => {
    await save();
    await chrome.runtime.sendMessage({ action: "CITYLINE_TEST_NOTIFICATION" });
  });

  $("clearLogsBtn").addEventListener("click", async () => {
    await chrome.storage.local.set({ citylineLogs: [] });
    renderLogs([]);
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.citylineRuntimeStatus) renderStatus(changes.citylineRuntimeStatus.newValue);
    if (changes.citylineLogs) renderLogs(changes.citylineLogs.newValue || []);
  });

  load();
})();