(() => {
  "use strict";

  const DEFAULTS = {
    scriptEnabled: true,
    eventKeyword: "",
    directEventUrl: "",
    performanceKeyword: "",
    priceKeyword: "",
    quantity: 1,
    purchaseMode: "express",
    memberLogin: "",
    memberPassword: "",
    autoSubmitLogin: false,
    notifications: {
      feishuWebhook: "",
      larkWebhook: "",
      telegramBotToken: "",
      telegramChatId: "",
      barkKey: "",
      ntfyTopic: ""
    }
  };

  chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

  chrome.runtime.onInstalled.addListener(async () => {
    const current = await chrome.storage.local.get(["citylineConfig", "citylineLogs"]);
    if (!current.citylineConfig) {
      await chrome.storage.local.set({ citylineConfig: DEFAULTS });
    }
    if (!Array.isArray(current.citylineLogs)) {
      await chrome.storage.local.set({ citylineLogs: [] });
    }
  });

  async function getConfig() {
    const data = await chrome.storage.local.get("citylineConfig");
    return Object.assign({}, DEFAULTS, data.citylineConfig || {}, {
      notifications: Object.assign({}, DEFAULTS.notifications, data.citylineConfig?.notifications || {})
    });
  }

  async function appendLog(entry) {
    const data = await chrome.storage.local.get("citylineLogs");
    const logs = Array.isArray(data.citylineLogs) ? data.citylineLogs : [];
    logs.unshift({
      at: Date.now(),
      level: entry?.level || "info",
      message: String(entry?.message || ""),
      url: String(entry?.url || "")
    });
    await chrome.storage.local.set({ citylineLogs: logs.slice(0, 200) });
    return { ok: true };
  }

  async function postJson(url, body, headers = {}) {
    const res = await fetch(url, {
      method: "POST",
      headers: Object.assign({ "Content-Type": "application/json" }, headers),
      body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return true;
  }

  async function sendFeishu(webhook, text) {
    if (!webhook) return { channel: "feishu", skipped: true };
    await postJson(webhook, { msg_type: "text", content: { text } });
    return { channel: "feishu", success: true };
  }

  async function sendLark(webhook, text) {
    if (!webhook) return { channel: "lark", skipped: true };
    await postJson(webhook, { msg_type: "text", content: { text } });
    return { channel: "lark", success: true };
  }

  async function sendTelegram(token, chatId, text) {
    if (!token || !chatId) return { channel: "telegram", skipped: true };
    await postJson("https://api.telegram.org/bot" + encodeURIComponent(token) + "/sendMessage", {
      chat_id: chatId,
      text
    });
    return { channel: "telegram", success: true };
  }

  async function sendBark(key, title, body) {
    if (!key) return { channel: "bark", skipped: true };
    const url = "https://api.day.app/" + encodeURIComponent(key) + "/" +
      encodeURIComponent(title) + "/" + encodeURIComponent(body);
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    return { channel: "bark", success: true };
  }

  async function sendNtfy(topic, title, body) {
    if (!topic) return { channel: "ntfy", skipped: true };
    const res = await fetch("https://ntfy.sh/" + encodeURIComponent(topic), {
      method: "POST",
      headers: { "Title": title },
      body
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    return { channel: "ntfy", success: true };
  }

  async function notifySuccess(payload) {
    const cfg = await getConfig();
    const n = cfg.notifications || {};
    const title = "Cityline 購票狀態";
    const body = String(payload?.message || "偵測到交易成功頁面");
    const text = title + "\n" + body + (payload?.url ? "\n" + payload.url : "");

    const jobs = [
      () => sendFeishu(n.feishuWebhook, text),
      () => sendLark(n.larkWebhook, text),
      () => sendTelegram(n.telegramBotToken, n.telegramChatId, text),
      () => sendBark(n.barkKey, title, body),
      () => sendNtfy(n.ntfyTopic, title, body)
    ];

    const results = [];
    for (const job of jobs) {
      try {
        results.push(await job());
      } catch (err) {
        results.push({ success: false, message: String(err?.message || err) });
      }
    }

    try {
      await chrome.notifications.create({
        type: "basic",
        iconUrl: "data:image/svg+xml;charset=utf-8," + encodeURIComponent(
          '<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><rect width="128" height="128" rx="24" fill="#111827"/><text x="64" y="77" text-anchor="middle" font-size="54" fill="white">CL</text></svg>'
        ),
        title,
        message: body
      });
    } catch (_) {}

    await appendLog({ level: "success", message: body, url: payload?.url || "" });
    return { ok: true, results };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      switch (message?.action) {
        case "CITYLINE_LOG":
          sendResponse(await appendLog({
            level: message.level,
            message: message.message,
            url: message.url || sender?.tab?.url || ""
          }));
          return;

        case "CITYLINE_SUCCESS":
          sendResponse(await notifySuccess(message.payload || {}));
          return;

        case "CITYLINE_TEST_NOTIFICATION":
          sendResponse(await notifySuccess({
            message: "Cityline 私人通知測試成功",
            url: "https://www.cityline.com/Events.html"
          }));
          return;

        case "CITYLINE_GET_CONFIG":
          sendResponse({ ok: true, config: await getConfig() });
          return;

        default:
          sendResponse({ ok: false, message: "unknown action" });
      }
    })().catch(err => sendResponse({ ok: false, message: String(err?.message || err) }));
    return true;
  });
})();