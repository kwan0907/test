(() => {
  "use strict";
  if (window.__CITYLINE_PRIVATE_ASSISTANT_V010__) return;
  window.__CITYLINE_PRIVATE_ASSISTANT_V010__ = true;

  const STATE = {
    busy: false,
    lastActionAt: 0,
    lastActionKey: "",
    successKey: "",
    mutationTimer: null
  };

  const TEXT = {
    queue: [
      "排隊中", "you are in the queue",
      "all internet ticketing sessions are currently taken up",
      "所有網上購票連結正由其他顧客使用中"
    ],
    human: [
      "captcha", "驗證碼", "人機驗證", "verify you are human",
      "cloudflare", "robot check", "機械人驗證"
    ],
    payment: [
      "payment details", "付款詳情", "credit card", "信用卡",
      "mastercard id check", "visa authentication", "safekey",
      "3d secure", "payme", "支付寶", "wechat pay", "微信支付"
    ],
    finalPreview: [
      "transaction preview", "交易預覽"
    ],
    success: [
      "online receipt", "網上收據", "transaction has been successfully completed",
      "交易已經完成", "purchase successful", "購票成功"
    ],
    buy: [
      "購票", "購買", "buy tickets", "purchase", "go to purchase", "立即購票"
    ],
    checkout: [
      "結帳", "check out", "checkout"
    ],
    express: [
      "快速購票", "express purchase"
    ],
    normal: [
      "一般購票", "normal purchase"
    ]
  };

  function norm(v) {
    return String(v == null ? "" : v).replace(/\s+/g, " ").trim().toLowerCase();
  }

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.display !== "none" && st.visibility !== "hidden";
  }

  function pageText() {
    return norm(document.body?.innerText || "");
  }

  function hasAny(hay, arr) {
    return arr.some(x => hay.includes(norm(x)));
  }

  function dispatch(el) {
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function setNativeValue(el, value) {
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc?.set) desc.set.call(el, value);
    else el.value = value;
    dispatch(el);
  }

  async function getConfig() {
    const data = await chrome.storage.local.get("citylineConfig");
    return data.citylineConfig || {};
  }

  async function status(state, detail) {
    await chrome.storage.local.set({
      citylineRuntimeStatus: {
        state,
        detail: String(detail || ""),
        url: location.href,
        at: Date.now()
      }
    });
  }

  function log(level, message) {
    chrome.runtime.sendMessage({
      action: "CITYLINE_LOG",
      level,
      message,
      url: location.href
    }).catch(() => {});
  }

  function canAct(key, gap = 900) {
    const now = Date.now();
    if (STATE.lastActionKey === key && now - STATE.lastActionAt < 4500) return false;
    if (now - STATE.lastActionAt < gap) return false;
    STATE.lastActionKey = key;
    STATE.lastActionAt = now;
    return true;
  }

  function click(el, key) {
    if (!visible(el) || !canAct(key)) return false;
    el.scrollIntoView({ block: "center", inline: "center" });
    el.click();
    log("action", "自動操作：" + key);
    return true;
  }

  function clickables() {
    return [...document.querySelectorAll(
      'a,button,[role="button"],input[type="button"],input[type="submit"],label'
    )].filter(visible);
  }

  function bestClickableByKeyword(keyword, hints = []) {
    const k = norm(keyword);
    if (!k) return null;
    let best = null, bestScore = -1;
    for (const el of clickables()) {
      const t = norm(el.innerText || el.value || el.getAttribute("aria-label") || "");
      if (!t.includes(k)) continue;
      let score = 10;
      for (const h of hints) if (t.includes(norm(h))) score += 2;
      if (el.tagName === "BUTTON" || el.getAttribute("role") === "button") score += 1;
      if (score > bestScore) { best = el; bestScore = score; }
    }
    return best;
  }

  function bestClickableByTexts(texts) {
    let best = null, score = -1;
    for (const el of clickables()) {
      const t = norm(el.innerText || el.value || el.getAttribute("aria-label") || "");
      for (const raw of texts) {
        const q = norm(raw);
        if (!q || !t.includes(q)) continue;
        let s = q.length;
        if (el.tagName === "BUTTON") s += 5;
        if (s > score) { best = el; score = s; }
      }
    }
    return best;
  }

  function selectOption(select, keyword, key) {
    if (!visible(select) || !keyword) return false;
    const k = norm(keyword);
    const option = [...select.options].find(o => norm(o.textContent).includes(k));
    if (!option || select.value === option.value) return false;
    if (!canAct(key)) return false;
    select.value = option.value;
    dispatch(select);
    log("action", "已選擇：" + option.textContent.trim());
    return true;
  }

  function trySelectByKeyword(keyword, hints, key) {
    if (!keyword) return false;
    const k = norm(keyword);
    const selects = [...document.querySelectorAll("select")].filter(visible);
    let fallback = null;
    for (const sel of selects) {
      const opts = [...sel.options];
      if (!opts.some(o => norm(o.textContent).includes(k))) continue;
      const ctx = norm(sel.closest("label,div,td,tr,section,form")?.innerText || "");
      if (hints.some(h => ctx.includes(norm(h)))) return selectOption(sel, keyword, key);
      fallback = fallback || sel;
    }
    return fallback ? selectOption(fallback, keyword, key) : false;
  }

  function tryQuantity(qty) {
    const wanted = String(Math.max(1, Number(qty) || 1));
    const selects = [...document.querySelectorAll("select")].filter(visible);
    for (const sel of selects) {
      const ctx = norm(sel.closest("label,div,td,tr,section,form")?.innerText || "");
      if (!/(數量|quantity|qty|門票|ticket)/i.test(ctx)) continue;
      const opt = [...sel.options].find(o => norm(o.textContent) === wanted || String(o.value) === wanted);
      if (opt && sel.value !== opt.value && canAct("選擇數量 " + wanted)) {
        sel.value = opt.value;
        dispatch(sel);
        log("action", "門票數量：" + wanted);
        return true;
      }
    }

    const numbers = [...document.querySelectorAll('input[type="number"]')].filter(visible);
    for (const input of numbers) {
      const ctx = norm(input.closest("label,div,td,tr,section,form")?.innerText || "");
      if (!/(數量|quantity|qty|門票|ticket)/i.test(ctx)) continue;
      if (String(input.value) !== wanted && canAct("輸入數量 " + wanted)) {
        setNativeValue(input, wanted);
        log("action", "門票數量：" + wanted);
        return true;
      }
    }
    return false;
  }

  function autofillLogin(cfg) {
    if (!cfg.memberLogin && !cfg.memberPassword) return false;
    let changed = false;
    const inputs = [...document.querySelectorAll("input")].filter(visible);

    if (cfg.memberLogin) {
      const user = inputs.find(el => {
        const s = norm([
          el.name, el.id, el.placeholder, el.autocomplete,
          el.closest("label,div,td")?.innerText
        ].join(" "));
        return el.type !== "password" && /(email|member|login|user|account|會員|帳號|電郵)/i.test(s);
      });
      if (user && !user.value) {
        setNativeValue(user, cfg.memberLogin);
        changed = true;
      }
    }

    if (cfg.memberPassword) {
      const pass = inputs.find(el => el.type === "password");
      if (pass && !pass.value) {
        setNativeValue(pass, cfg.memberPassword);
        changed = true;
      }
    }

    if (changed) log("action", "已填入 Cityline 會員登入資料（本機）");

    if (cfg.autoSubmitLogin) {
      const btn = bestClickableByTexts(["會員登入", "登入", "member login", "login", "sign in"]);
      if (btn) return click(btn, "會員登入");
    }
    return changed;
  }

  function looksLikeEventListing() {
    const u = location.pathname.toLowerCase();
    return u.includes("events") || u.includes("buytickets");
  }

  async function notifySuccessOnce(text) {
    const key = location.href + "|" + text.slice(0, 80);
    if (STATE.successKey === key) return;
    STATE.successKey = key;
    await status("success", text);
    chrome.runtime.sendMessage({
      action: "CITYLINE_SUCCESS",
      payload: { message: text, url: location.href }
    }).catch(() => {});
  }

  async function cycle(manual = false) {
    if (STATE.busy) return;
    STATE.busy = true;
    try {
      const cfg = await getConfig();
      if (!cfg.scriptEnabled && !manual) {
        await status("paused", "自動化已暫停");
        return;
      }

      const body = pageText();
      if (!body) return;

      if (hasAny(body, TEXT.success)) {
        await notifySuccessOnce("偵測到 Cityline 交易完成／收據頁面");
        return;
      }

      if (hasAny(body, TEXT.queue)) {
        await status("queue", "Cityline 排隊中；保持原頁面，讓 Cityline 自己重試");
        return;
      }

      if (hasAny(body, TEXT.human)) {
        await status("human", "偵測到 CAPTCHA／人機驗證，需要你手動完成");
        return;
      }

      if (hasAny(body, TEXT.finalPreview)) {
        await status("confirm", "已到交易預覽；最後確認由你本人按");
        return;
      }

      if (hasAny(body, TEXT.payment)) {
        await status("payment", "已到付款／付款驗證步驟；付款由你本人完成");
        return;
      }

      if (autofillLogin(cfg)) {
        await status("login", "登入資料已填入");
        return;
      }

      if (cfg.eventKeyword && looksLikeEventListing()) {
        const el = bestClickableByKeyword(cfg.eventKeyword, ["活動", "event"]);
        if (el && click(el, "選擇活動：" + cfg.eventKeyword)) {
          await status("event", "已嘗試選擇活動");
          return;
        }
      }

      if (cfg.performanceKeyword) {
        if (trySelectByKeyword(
          cfg.performanceKeyword,
          ["日期", "時間", "場次", "performance", "date", "time"],
          "選擇場次：" + cfg.performanceKeyword
        )) {
          await status("performance", "已選擇場次");
          return;
        }

        const perf = bestClickableByKeyword(
          cfg.performanceKeyword,
          ["日期", "時間", "場次", "performance"]
        );
        if (perf && click(perf, "選擇場次：" + cfg.performanceKeyword)) {
          await status("performance", "已嘗試選擇場次");
          return;
        }
      }

      if (cfg.priceKeyword) {
        if (trySelectByKeyword(
          cfg.priceKeyword,
          ["票價", "price", "zone", "區"],
          "選擇票價：" + cfg.priceKeyword
        )) {
          await status("price", "已選擇票價");
          return;
        }

        const price = bestClickableByKeyword(
          cfg.priceKeyword,
          ["票價", "price", "zone"]
        );
        if (price && click(price, "選擇票價：" + cfg.priceKeyword)) {
          await status("price", "已嘗試選擇票價");
          return;
        }
      }

      if (tryQuantity(cfg.quantity || 1)) {
        await status("quantity", "已設定門票數量");
        return;
      }

      if (cfg.purchaseMode === "express") {
        const express = bestClickableByTexts(TEXT.express);
        if (express && click(express, "快速購票")) {
          await status("mode", "已選快速購票");
          return;
        }
      } else if (cfg.purchaseMode === "normal") {
        const normal = bestClickableByTexts(TEXT.normal);
        if (normal && click(normal, "一般購票")) {
          await status("mode", "已選一般購票");
          return;
        }
      }

      const checkout = bestClickableByTexts(TEXT.checkout);
      if (checkout && click(checkout, "前往結帳")) {
        await status("checkout", "已前往結帳");
        return;
      }

      const buy = bestClickableByTexts(TEXT.buy);
      if (buy) {
        const txt = norm(buy.innerText || buy.value || "");
        if (!/(付款|payment|confirm transaction|確認交易)/i.test(txt) &&
            click(buy, "購票／下一步")) {
          await status("buy", "已嘗試進入下一步");
          return;
        }
      }

      await status("watching", "正在監察 Cityline 頁面");
    } catch (err) {
      log("error", String(err?.message || err));
      await status("error", String(err?.message || err));
    } finally {
      STATE.busy = false;
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.action === "CITYLINE_RUN_NOW") {
      cycle(true).then(() => sendResponse({ ok: true })).catch(err => {
        sendResponse({ ok: false, message: String(err?.message || err) });
      });
      return true;
    }
  });

  function scheduleCycle() {
    clearTimeout(STATE.mutationTimer);
    STATE.mutationTimer = setTimeout(() => cycle(false), 450);
  }

  const observer = new MutationObserver(scheduleCycle);
  observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });

  document.addEventListener("DOMContentLoaded", () => cycle(false), { once: true });
  setInterval(() => cycle(false), 1400);
})();